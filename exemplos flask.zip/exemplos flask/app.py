from flask import Flask, render_template

app = Flask(__name__)

#http://127.0.0.1:5000
@app.route('/')
def home():
    return render_template('index.html')

#http://127.0.0.1:5000/teste
@app.route('/links')
def teste():
    return render_template('links.html')

#http://127.0.0.1:5000/variaveis/
@app.route('/variaveis/<nome>')
def variaveis(nome):
    return render_template('variaveis.html', nomehtml=nome)

#http://127.0.0.1:5000/personalizado/
@app.route('/personalizado/<nome>')
def personalizado(nome):
    return render_template('personalizado.html', nomehtml=nome)

#http://127.0.0.1:5000/desafio/
@app.route('/desafio/<nome>/<cor>')
def desafio(nome, cor):
    return render_template('desafio.html', nomehtml=nome, corhtml=cor)

app.run(debug=True)